USE [restaurant_management_system]
GO

DELETE FROM [dbo].[crew]
      WHERE <Search Conditions,,>
GO


DELETE FROM dbo.crew
WHERE crew_id = 1