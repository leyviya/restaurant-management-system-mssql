USE [restaurant_management_system]
GO

DELETE FROM [dbo].[ingredient]
      WHERE <Search Conditions,,>
GO


DELETE FROM dbo.ingredient 
WHERE ingredient_id = 3