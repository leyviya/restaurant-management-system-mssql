create database restaurant_management_system;


create table chef(
chef_id int,
name varchar(50)

);